package com.example.island

import android.app.*
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.MediaMetadata
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.*
import android.util.Base64
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.min

class IslandService : Service() {
    // Если Google сменит название модели, поменяй здесь:
    private val MODEL = "gemini-3.8-flash"
    private val PROMPT = "Опиши кратко, что на этом экране, и подскажи, что можно сделать. Отвечай по-русски."

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var pill: LinearLayout
    private lateinit var header: TextView
    private lateinit var panel: LinearLayout
    private lateinit var playBtn: TextView
    private lateinit var answer: TextView
    private lateinit var scroll: ScrollView
    private lateinit var lp: WindowManager.LayoutParams
    private var expanded = false
    private var moveMode = false
    private val posPrefs get() = getSharedPreferences("island", MODE_PRIVATE)
    private fun orient() = realSize().let { if (it.first > it.second) "land" else "port" }
    private var controller: MediaController? = null

    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
        private var started = false

    private val dp get() = resources.displayMetrics.density

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, f: Int, id: Int): Int {
        if (started || intent == null) return START_NOT_STICKY
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("island", "Island", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "island")
            .setContentTitle("Island работает").setSmallIcon(android.R.drawable.ic_menu_compass).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra("data", Intent::class.java)
                   else @Suppress("DEPRECATION") intent.getParcelableExtra("data")
        projection = mpm.getMediaProjection(intent.getIntExtra("code", 0), data!!).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, ui)
        }
        started = true
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        setupCapture()
        buildIsland()
        tick.run()
        return START_NOT_STICKY
    }

    // ---------- Интерфейс острова ----------
    private fun tv(t: String, size: Float = 15f, click: (() -> Unit)? = null) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding((12 * dp).toInt(), (8 * dp).toInt(), (12 * dp).toInt(), (8 * dp).toInt())
        click?.let { c -> setOnClickListener { c() } }
    }

    private fun buildIsland() {
        pill = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { setColor(Color.BLACK); cornerRadius = 26 * dp }
            setPadding((8 * dp).toInt(), (2 * dp).toInt(), (8 * dp).toInt(), (6 * dp).toInt())
        }
        header = tv("", 14f) {
            expanded = !expanded
            panel.visibility = if (expanded) View.VISIBLE else View.GONE
            applyLayout()
        }.apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        header.setOnTouchListener(object : View.OnTouchListener {
            var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                if (!moveMode) return false
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = lp.x; sy = lp.y; moved = false }
                    MotionEvent.ACTION_MOVE -> {
                        val ox = e.rawX - dx; val oy = e.rawY - dy
                        if (Math.abs(ox) > 10 * dp || Math.abs(oy) > 10 * dp) moved = true
                        if (moved) {
                            val (w, h, _) = realSize()
                            val lim = (w / 2 - 40 * dp).toInt()
                            lp.x = (sx + ox).toInt().coerceIn(-lim, lim)
                            lp.y = (sy + oy).toInt().coerceIn(0, h - (80 * dp).toInt())
                            wm.updateViewLayout(pill, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> { if (moved) savePosition() else endMove() }
                }
                return true
            }
        })
        pill.addView(header)

        panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row.addView(tv("⏮", 22f) { controller?.transportControls?.skipToPrevious() })
        playBtn = tv("⏯", 22f) {
            val c = controller
            if (c?.playbackState?.state == PlaybackState.STATE_PLAYING) c.transportControls.pause()
            else c?.transportControls?.play()
        }
        row.addView(playBtn)
        row.addView(tv("⏭", 22f) { controller?.transportControls?.skipToNext() })
        panel.addView(row)
        panel.addView(tv("👁 Спросить ИИ про экран") { askAboutScreen() })
        val row2 = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row2.addView(tv("✥ Переместить", 13f) { startMove() })
        row2.addView(tv("↺ Сбросить место", 13f) {
            lp.x = 0; lp.y = (6 * dp).toInt(); savePosition(); wm.updateViewLayout(pill, lp)
        })
        panel.addView(row2)
        answer = TextView(this).apply { setTextColor(Color.LTGRAY); textSize = 14f; setPadding((8 * dp).toInt(), 0, (8 * dp).toInt(), 0) }
        scroll = ScrollView(this).apply { addView(answer); visibility = View.GONE }
        panel.addView(scroll)
        pill.addView(panel)

        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = (6 * dp).toInt() }
        applyPosition()
        wm.addView(pill, lp)
        applyLayout()
    }

    private fun applyPosition() {
        val o = orient()
        lp.x = (posPrefs.getFloat("x_$o", 0f) * dp).toInt()
        lp.y = (posPrefs.getFloat("y_$o", 6f) * dp).toInt()
        if (pill.isAttachedToWindow) wm.updateViewLayout(pill, lp)
    }

    private fun savePosition() {
        val o = orient()
        posPrefs.edit().putFloat("x_$o", lp.x / dp).putFloat("y_$o", lp.y / dp).apply()
    }

    private fun startMove() {
        moveMode = true; expanded = false; panel.visibility = View.GONE
        header.text = "✥ Тащи меня · тап = готово"
        applyLayout()
    }

    private fun endMove() {
        moveMode = false
        header.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
    }

    /** Подгоняет размеры под текущую ориентацию (портрет / альбом). */
    private fun applyLayout() {
        val m = DisplayMetrics().also { @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(it) }
        header.maxWidth = (min(m.widthPixels * 0.6f, 220 * dp)).toInt()
        pill.minimumWidth = if (expanded) min(300 * dp, m.widthPixels - 24 * dp).toInt() else 0
        scroll.layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, (m.heightPixels * 0.35f).toInt())
        scroll.visibility = if (expanded && answer.text.isNotEmpty()) View.VISIBLE else View.GONE
        if (pill.isAttachedToWindow) wm.updateViewLayout(pill, lp)
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        if (started) { applyLayout(); applyPosition(); resetCapture() }
    }

    // ---------- Музыка + часы ----------
    private val tick = object : Runnable {
        override fun run() {
            if (moveMode) { ui.postDelayed(this, 2000); return }
            try {
                val msm = getSystemService(MediaSessionManager::class.java)
                controller = msm.getActiveSessions(ComponentName(this@IslandService, MediaListener::class.java)).firstOrNull()
            } catch (e: SecurityException) { controller = null }
            val title = controller?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            val playing = controller?.playbackState?.state == PlaybackState.STATE_PLAYING
            val t = if (!title.isNullOrBlank()) (if (playing) "♪ " else "⏸ ") + title
                    else SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            if (header.text.toString() != t) header.text = t
            ui.postDelayed(this, 2000)
        }
    }

    // ---------- Захват экрана + ИИ ----------
    private fun realSize(): Triple<Int, Int, Int> {
        val m = DisplayMetrics().also { @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(it) }
        return Triple(m.widthPixels, m.heightPixels, m.densityDpi)
    }

    // Захват включается только на момент снимка, иначе телефон постоянно копирует каждый кадр и тормозит.
    private fun setupCapture() {
        val (w, h, dpi) = realSize()
        vd = projection!!.createVirtualDisplay("island", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, null, null, null)
    }

    private fun resetCapture() {
        val (w, h, dpi) = realSize()
        vd?.resize(w, h, dpi)
    }

    private fun startCapture() {
        val (w, h, _) = realSize()
        reader?.close()
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd?.surface = reader!!.surface
    }

    private fun stopCapture() {
        vd?.surface = null
        reader?.close()
        reader = null
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        val pl = img.planes[0]
        val w = img.width; val h = img.height
        val pad = pl.rowStride - pl.pixelStride * w
        val raw = Bitmap.createBitmap(w + pad / pl.pixelStride, h, Bitmap.Config.ARGB_8888)
        raw.copyPixelsFromBuffer(pl.buffer)
        img.close()
        return Bitmap.createBitmap(raw, 0, 0, w, h)
    }

    private fun askAboutScreen() {
        val key = getSharedPreferences("island", MODE_PRIVATE).getString("key", "") ?: ""
        if (key.isEmpty()) { show("Нет ключа Gemini: открой приложение Island и вставь его."); return }
        show("Смотрю на экран…")
        pill.visibility = View.INVISIBLE            // чтобы остров не попал в кадр
        startCapture()
        var tries = 0
        val poll = object : Runnable {
            override fun run() {
                val shot = grab()
                if (shot == null && ++tries < 20) { ui.postDelayed(this, 100); return }
                stopCapture()
                pill.visibility = View.VISIBLE
                if (shot == null) { show("Не удалось снять экран."); return }
                Thread {
                    val text = try { callGemini(key, shot) } catch (e: Exception) { "Ошибка: ${e.message}" }
                    ui.post { show(text) }
                }.start()
            }
        }
        ui.postDelayed(poll, 300)
    }

    private fun show(t: String) { answer.text = t; applyLayout() }

    private fun callGemini(key: String, shot: Bitmap): String {
        val k = 1024f / maxOf(shot.width, shot.height)
        val small = Bitmap.createScaledBitmap(shot, (shot.width * k).toInt(), (shot.height * k).toInt(), true)
        val out = ByteArrayOutputStream().also { small.compress(Bitmap.CompressFormat.JPEG, 80, it) }
        val b64 = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        val body = JSONObject().put("contents", JSONArray().put(JSONObject().put("parts", JSONArray()
            .put(JSONObject().put("text", PROMPT))
            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64))))))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=$key")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val resp = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) return "Ошибка ${c.responseCode}: " + resp.take(300)
        return JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        if (::pill.isInitialized && pill.isAttachedToWindow) wm.removeView(pill)
        vd?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
